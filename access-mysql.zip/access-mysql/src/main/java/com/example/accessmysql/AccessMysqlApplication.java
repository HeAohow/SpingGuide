package com.example.accessmysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccessMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccessMysqlApplication.class, args);
	}

}
