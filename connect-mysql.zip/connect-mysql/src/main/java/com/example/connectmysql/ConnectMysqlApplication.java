package com.example.connectmysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectMysqlApplication.class, args);
	}

}
