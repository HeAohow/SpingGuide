package com.example.connectmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
